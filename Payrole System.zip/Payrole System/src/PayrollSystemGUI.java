import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

abstract class Employee {
    private String name;
    private int id;

    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public abstract double calculateSalary();

    @Override
    public String toString() {
        return "Employee[name=" + name + ", id=" + id + ", salary=" + calculateSalary() + "]";
    }
}

class FullTimeEmployee extends Employee {
    private double monthlySalary;

    public FullTimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }

    @Override
    public double calculateSalary() {
        return monthlySalary;
    }
}

class PartTimeEmployee extends Employee {
    private int hoursWorked;
    private double hourlyRate;

    public PartTimeEmployee(String name, int id, int hoursWorked, double hourlyRate) {
        super(name, id);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculateSalary() {
        return hourlyRate * hoursWorked;
    }
}

class PayrollSystem {
    private ArrayList<Employee> employeeList;

    public PayrollSystem() {
        employeeList = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employeeList.add(employee);
    }

    public void removeEmployee(int id) {
        employeeList.removeIf(employee -> employee.getId() == id);
    }

    public String displayEmployees() {
        if (employeeList.isEmpty()) {
            return "No employees in the system.";
        }
        StringBuilder result = new StringBuilder();
        for (Employee employee : employeeList) {
            result.append(employee).append("\n");
        }
        return result.toString();
    }
}

public class PayrollSystemGUI extends JFrame {
    private PayrollSystem payrollSystem;
    private JTextField nameField, idField, salaryField, hoursField, rateField, removeIdField;
    private JTextArea displayArea;
    private JComboBox<String> employeeTypeDropdown;

    public PayrollSystemGUI() {
        payrollSystem = new PayrollSystem();

        setTitle("Payroll System");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 5, 5));

        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Employee Type:"));
        String[] employeeTypes = {"Full-Time", "Part-Time"};
        employeeTypeDropdown = new JComboBox<>(employeeTypes);
        inputPanel.add(employeeTypeDropdown);

        inputPanel.add(new JLabel("Monthly Salary (Full-Time):"));
        salaryField = new JTextField();
        inputPanel.add(salaryField);

        inputPanel.add(new JLabel("Hours Worked (Part-Time):"));
        hoursField = new JTextField();
        inputPanel.add(hoursField);

        inputPanel.add(new JLabel("Hourly Rate (Part-Time):"));
        rateField = new JTextField();
        inputPanel.add(rateField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        JButton addButton = new JButton("Add Employee");
        JButton removeButton = new JButton("Remove Employee");
        JButton displayButton = new JButton("Display Employees");

        addButton.setPreferredSize(new Dimension(150, 30));
        removeButton.setPreferredSize(new Dimension(150, 30));
        displayButton.setPreferredSize(new Dimension(150, 30));

        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(displayButton);

        removeIdField = new JTextField(10);
        JPanel removePanel = new JPanel(new FlowLayout());
        removePanel.add(new JLabel("Enter ID to Remove: "));
        removePanel.add(removeIdField);

        displayArea = new JTextArea(8, 40);
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(removePanel, BorderLayout.SOUTH);
        add(scrollPane, BorderLayout.EAST);

        addButton.addActionListener(e -> addEmployee());
        removeButton.addActionListener(e -> removeEmployee());
        displayButton.addActionListener(e -> displayEmployees());
    }

    private void addEmployee() {
        try {
            String name = nameField.getText();
            int id = Integer.parseInt(idField.getText());
            String employeeType = (String) employeeTypeDropdown.getSelectedItem();

            if (employeeType.equals("Full-Time")) {
                double salary = Double.parseDouble(salaryField.getText());
                payrollSystem.addEmployee(new FullTimeEmployee(name, id, salary));
            } else {
                int hoursWorked = Integer.parseInt(hoursField.getText());
                double hourlyRate = Double.parseDouble(rateField.getText());
                payrollSystem.addEmployee(new PartTimeEmployee(name, id, hoursWorked, hourlyRate));
            }

            JOptionPane.showMessageDialog(this, "Employee added successfully!");
            clearFields();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check the fields.");
        }
    }

    private void removeEmployee() {
        try {
            int id = Integer.parseInt(removeIdField.getText());
            payrollSystem.removeEmployee(id);
            JOptionPane.showMessageDialog(this, "Employee removed successfully!");
            removeIdField.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid ID. Please enter a numeric value.");
        }
    }

    private void displayEmployees() {
        displayArea.setText(payrollSystem.displayEmployees());
        displayArea.setCaretPosition(0);
    }

    private void clearFields() {
        nameField.setText("");
        idField.setText("");
        salaryField.setText("");
        hoursField.setText("");
        rateField.setText("");
        removeIdField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PayrollSystemGUI().setVisible(true));
    }
}